import style from '@/styles/Tabuleiro.module.css'
export default function Branco(){
    return(
        <div>
        <div className={style.Branco}></div>
        
        </div>

    )

}
