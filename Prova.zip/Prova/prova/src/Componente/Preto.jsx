import style from '@/styles/Tabuleiro.module.css'
export default function Preto(){
    return(
        
        <div>
            <div className={style.Preto}></div>
        </div>

    )

}
