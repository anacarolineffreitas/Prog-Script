import style from '@/styles/Tabuleiro.module.css'
export default function PecaBranca(){
    return(
        <div>
        <div className={style.PecaBranca}></div>
        
        </div>

    )

}