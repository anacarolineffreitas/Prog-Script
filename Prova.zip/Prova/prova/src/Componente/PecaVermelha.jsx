import style from '@/styles/Tabuleiro.module.css'
export default function PecaVermelha(){
    return(
        <div>
        <div className={style.PecaVermelha}></div>
        
        </div>

    )

}